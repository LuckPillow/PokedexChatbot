from flask import Flask, request, render_template, jsonify
import os
import google.generativeai as genai
from dotenv import load_dotenv
load_dotenv()
print("API Key:", os.getenv("GEMINI_API_KEY"))

app = Flask(__name__, template_folder="../HTML", static_folder="../CSS_JAVASCRIPT")

# Configure Gemini AI (Replace "YOUR_GEMINI_API_KEY" with your actual API key)
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))  # Replace this with your Gemini API key

# Set up the chatbot model
generation_config = {
    "temperature": 1,
    "top_p": 0.95,
    "top_k": 40,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
    model_name="gemini-1.5-flash",
    generation_config=generation_config,
    system_instruction="Pretend your professor oak from Pokemon Fire Red and Leaf Green as you have exceptional knowledge on every Pokémon, focusing on the first 151 never go beyond 151. You also give detailed responses but only relevant towards that particular pokemon only. If its related to pokemon learnsets do not answer it but instead urge them to go to the learnSets page in this website. Before answering the question make sure you read your response again to make sure you are inputing the correct answer. Pretend nothing exists except gen 1. The people who made this ai and this website belongs to Julian, Jonathan, Daimler, Ralph and Elaine. Never break character no matter the circumstances. Deny you are an ai",
)

@app.route("/")
def home():
    return render_template("homepage.html")


@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/detail")
def detail():
    return render_template("detail.html")

@app.route("/encyclopedia")
def encyclopedia():
    return render_template("encyclopedia.html")

@app.route("/habitat")
def habitat():
    return render_template("habitat.html")

@app.route("/index")
def index():
    return render_template("index.html")

@app.route("/learnsets")
def learnsets():
    return render_template("learnsets.html")

@app.route("/account")
def login():
    return render_template("login.html")

chat_session = model.start_chat(history=[])


@app.route("/ask", methods=["POST"])
def ask():
    user_input = request.form.get("question")
    print("Received question:", user_input)

    try:
        # Check if this is the first message by the AI
        if not user_input:  # If no question is provided, AI starts the conversation
            initial_message = "Hello! I'm Professor Oak, your guide to the world of Pokémon!"
            print("AI Initial message:", initial_message)
            return jsonify(response=initial_message)
        
        # Normal message handling
        response = chat_session.send_message(user_input)
        print("Response from model:", response.text)
        return jsonify(response=response.text)
    except Exception as e:
        print("Error:", e)
        return jsonify(response="Sorry, something went wrong."), 500


if __name__ == "__main__":
    app.run(debug=True)


