document.addEventListener("DOMContentLoaded", () => {
  const MAX_POKEMONS = 151;
  let currentPokemonId = parseInt(new URLSearchParams(window.location.search).get("id")) || 1;

  loadPokemon(currentPokemonId);

  // Set up Previous and Next button event listeners
  document.getElementById("prevButton").addEventListener("click", () => {
    if (currentPokemonId > 1) {
      currentPokemonId--;
      loadPokemon(currentPokemonId);
    }
  });

  document.getElementById("nextButton").addEventListener("click", () => {
    if (currentPokemonId < MAX_POKEMONS) {
      currentPokemonId++;
      loadPokemon(currentPokemonId);
    }
  });

  // Search on Enter key press
  document.getElementById("search-input").addEventListener("keypress", (event) => {
    if (event.key === "Enter") {
      const searchValue = event.target.value.trim().toLowerCase();
      if (searchValue) {
        // Check if the input is a number (ID) or a name (string)
        let pokemonIdOrName = !isNaN(searchValue) ? parseInt(searchValue) : searchValue;
        loadPokemon(pokemonIdOrName);
      }
    }
  });
});

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

async function loadPokemon(idOrName) {
  try {
    // Fetch Pokémon data using either name or ID
    const pokemonResponse = await fetch(`https://pokeapi.co/api/v2/pokemon/${idOrName}`);
    if (!pokemonResponse.ok) throw new Error(`Failed to fetch data for Pokémon: ${idOrName}`);
    const pokemonData = await pokemonResponse.json();

    // Set Pokémon name in header
    const pokemonName = capitalizeFirstLetter(pokemonData.name);
    document.querySelector(".pokemon-name").textContent = `Moveset for ${pokemonName}`;
    
    // Set Pokémon image
    const pokemonImage = document.getElementById("pokemon-image");
    pokemonImage.src = `https://raw.githubusercontent.com/LuckPillow/PokedexChatbot/refs/heads/main/ASSETS/pokemon/${pokemonData.id}.png`;
    pokemonImage.alt = `Image of ${pokemonName}`;

    // Clear existing moveset
    const movesetList = document.getElementById("moveset-list");
    movesetList.innerHTML = "";

    // Get level-up moves specific to FireRed-LeafGreen, Ruby-Sapphire, and Emerald
    const levelUpMoves = pokemonData.moves
      .filter(moveEntry => 
        moveEntry.version_group_details.some(detail => 
          detail.move_learn_method.name === "level-up" &&
          ["firered-leafgreen", "ruby-sapphire", "emerald"].includes(detail.version_group.name)
        )
      )
      .map(moveEntry => {
        const versionDetail = moveEntry.version_group_details.find(detail => 
          ["firered-leafgreen", "ruby-sapphire", "emerald"].includes(detail.version_group.name)
        );
        return {
          moveName: capitalizeFirstLetter(moveEntry.move.name),
          levelLearned: versionDetail.level_learned_at,
          moveUrl: moveEntry.move.url
        };
      })
      .filter(move => move.levelLearned > 0)
      .sort((a, b) => a.levelLearned - b.levelLearned);

    // Populate moveset table with power, accuracy, and PP details
    for (const move of levelUpMoves) {
      const stats = await getMoveStats(move);
      const row = document.createElement("tr");
      row.innerHTML = `
        <td class="clickable-move">${move.moveName}</td>
        <td>${move.levelLearned}</td>
        <td>FireRed-LeafGreen</td>
        <td>Level-Up</td>
        <td>${stats.power}</td>
        <td>${stats.accuracy}</td>
        <td>${stats.pp}</td>
      `;
      row.querySelector(".clickable-move").addEventListener("click", () => showMoveDetails(move.moveUrl, move.moveName));
      movesetList.appendChild(row);
    }
  } catch (error) {
    console.error("An error occurred:", error);
    document.querySelector(".pokemon-name").textContent = "Pokémon not found";
    document.getElementById("pokemon-image").src = ""; // Clear image if Pokémon not found
  }
}
const manualMoveStats = {
  "vine-whip": { power: 35, accuracy: 100, pp: 25 },
  "flamethrower": { power: 95, accuracy: 100, pp: 15 },
  "heat-wave": { power: 100, accuracy: 90, pp: 10 },
  "wing-attack": { power: 60, accuracy: 100, pp: 35 },
  "bubble": { power: 20, accuracy: 100, pp: 30 },
  "rapid-spin": { power: 20, accuracy: 100, pp: 40 },
  "skull-bash": { power: 100, accuracy: 100, pp: 15 },
  "hydro-pump": { power: 120, accuracy: 80, pp: 5 },
  "pin-missile": { power: 14, accuracy: 85, pp: 20 },
  "whirlwind": { power: '—', accuracy: 100, pp: 20 },
  "spit-up": { power: 100, accuracy: 100, pp: 10 }, //Arbok
  "thunder-wave": { power: '-', accuracy: 100, pp: 20 }, //Pikachu
  "thunderbolt": { power: 95, accuracy: 100, pp: 15 }, //Pikachu
  "thunder": { power: 120, accuracy: 70, pp: 10 }, //Pikachu
  "minimize": { power: '-', accuracy: '-', pp: 20 }, //Clefairy
  "meteor-mash": { power: 100, accuracy: 85, pp: 10 }, //Clefairy
  "roar": { power: '-', accuracy: 100, pp: 20 }, //Vulpix
  "will-o-wisp": { power: '-', accuracy: 75, pp: 15 }, //Vulpix
  "rest": { power: '-', accuracy: '-', pp: 10  }, //Jigglypuff
  "double-edge": { power: 120, accuracy: '-', pp: 10  }, //Jigglypuff
  "leech-life": { power: 20, accuracy: 100, pp: 15  }, //Zubat
  "air-cutter": { power: 55, accuracy: 95, pp: 25  }, //Zubat
  "petal-dance": { power: 70, accuracy: 100, pp: 20  }, //Oddish
  "growth": { power: '-', accuracy: '-', pp: 40  }, //Paras
  "giga-drain": { power: 60, accuracy: 100, pp: 5  }, //Paras
  "foresight": { power: '-', accuracy: 100, pp: 40  }, //Venonat
  "dig": { power: 60, accuracy: 100, pp: 10  }, //Diglett
  "odor-sleuth": { power: '-', accuracy: 100, pp: 40  }, //Growlith
  "mind-reader": { power: '-', accuracy: 100, pp: 5  }, //Poliwrath
  "submission": { power: 80, accuracy: 80, pp: 25  }, //Poliwrath
  "low-kick": { power: '-', accuracy: 100, pp: 20  }, //Machop
  "vine-whip": { power: 35, accuracy: 100, pp: 10  }, //Bellsprout
  "barrier": { power: '-', accuracy: '-', pp: 30  }, //Tentacool
  "self-destruct": { power: 200, accuracy: 100, pp: 5 }, //geodude
  "explosion": { power: 250, accuracy: 100, pp: 5 }, //geodude
  "double-edge": { power: 120, accuracy: 100, pp: 15 }, //geodude
  "fire-blast": { power: 120, accuracy: 85, pp: 5 }, //Ponyta
  "lock-on": { power: '-', accuracy: 100, pp: 5 }, //
  "knock-off": { power: 20, accuracy: 100, pp: 20 }, //Farfetched
  "swords-dance": { power: '-', accuracy: '-', pp: 30 }, //Farfetched
  "ice-beam": { power: 95, accuracy: 100, pp: 10 }, //Seel
  "acid-armor": { power: '-', accuracy: '-', pp: 40 }, //Grimer
  "lick": { power: 30, accuracy: 100, pp: 30 }, //Gastly
  "nightmare": { power: '-', accuracy: 100, pp: 15 }, //Gastly
  "rock-throw": { power: 50, accuracy: 90, pp: 15 }, //Onix
  "crabhammer": { power: 90, accuracy: 85, pp: 10 }, //Krabby
  "jump-kick": { power: 70, accuracy: 95, pp: 25 }, //Hitmonlee
  "lick": { power: 20, accuracy: 100, pp: 30 }, //Likitung
  "memento": { power: '-', accuracy: 100, pp: 10 }, //Koffing
  "smog": { power: 20, accuracy: 70, pp: 20 }, //Koffing
  "soft-boiled": { power: '-', accuracy: '-', pp: 5 }, //Chansey
  "blizzard": { power: 120, accuracy: 70, pp: 5 },
  "snore  ": { power: 40, accuracy: 100, pp: 15 } //Snorlax

  // Add additional moves here if needed
};

async function getMoveStats(move) {
  const moveNameKey = move.moveName.toLowerCase();

  if (manualMoveStats[moveNameKey]) {
    return manualMoveStats[moveNameKey];
  }

  try {
    const moveResponse = await fetch(move.moveUrl);
    if (!moveResponse.ok) throw new Error(`Failed to fetch details for move: ${move.moveName}`);
    const moveData = await moveResponse.json();

    const selectedStats = moveData.past_values.find(value => 
      ["firered-leafgreen", "ruby-sapphire", "emerald"].includes(value.version_group.name)
    ) || moveData.past_values.find(value => 
      ["black-white", "diamond-pearl", "gold-silver"].includes(value.version_group.name)
    ) || {};

    return {
      power: selectedStats.power ?? moveData.power ?? "—",
      accuracy: selectedStats.accuracy ?? moveData.accuracy ?? "—",
      pp: selectedStats.pp ?? moveData.pp ?? "—"
    };
  } catch (error) {
    console.error(`Failed to fetch details for move: ${move.moveName}`, error);
    return { power: "—", accuracy: "—", pp: "—" };
  }
}

async function showMoveDetails(moveUrl, moveName) {
  try {
    const moveResponse = await fetch(moveUrl);
    if (!moveResponse.ok) throw new Error(`Failed to fetch details for ${moveName}`);
    const moveData = await moveResponse.json();

    const moveDescription = moveData.flavor_text_entries.find(
      entry => entry.language.name === "en"
    )?.flavor_text || "No description available for this move.";

    document.getElementById("move-name").textContent = moveName;
    document.getElementById("move-description").textContent = moveDescription;
    document.getElementById("move-details").style.display = "block";
  } catch (error) {
    console.error("An error occurred while fetching move details:", error);
    document.getElementById("move-description").textContent = "Error fetching move details.";
    document.getElementById("move-details");
  }
}

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

// Function to handle search input and fetch Pokémon data based on name or ID
async function searchPokemon() {
  const searchInput = document.getElementById("search-input").value.trim().toLowerCase();
  
  // Check if the input is a number (ID) or a string (name)
  if (searchInput) {
    let pokemonIdOrName = searchInput;

    // Check if the input is numeric (ID)
    if (!isNaN(pokemonIdOrName)) {
      pokemonIdOrName = parseInt(pokemonIdOrName); // Convert to integer for ID
    }

    // Call loadPokemon with the entered name or ID
    loadPokemon(pokemonIdOrName);
  }
}