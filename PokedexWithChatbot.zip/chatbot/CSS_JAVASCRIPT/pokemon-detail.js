let currentPokemonId = null;

document.addEventListener("DOMContentLoaded", () => {
  const MAX_POKEMONS = 151;
  const pokemonID = new URLSearchParams(window.location.search).get("id");
  const id = parseInt(pokemonID, 10);

  if (id < 1 || id > MAX_POKEMONS) {
    return (window.location.href = "./index.html");
  }

  currentPokemonId = id;
  loadPokemon(id);
  loadPokemonList();
});

async function loadPokemon(id) {
  try {
    const [pokemon, pokemonSpecies, typeData] = await Promise.all([
      fetch(`https://pokeapi.co/api/v2/pokemon/${id}`).then(res => res.json()),
      fetch(`https://pokeapi.co/api/v2/pokemon-species/${id}`).then(res => res.json()),
      fetch(`https://pokeapi.co/api/v2/type/`).then(res => res.json()), // Fetch all types
    ]);

    // Filter out types with IDs > 15 (Gen 1-3 types only)
    const allowedTypes = typeData.results.filter(type => {
      const typeId = parseInt(type.url.split("/").slice(-2, -1)[0], 10);
      return typeId >= 1 && typeId <= 15; // Gen 1-3 (ID 1 to 15)
    });

    // Filter Pokémon's types to include only those allowed (Gen 1-3)
    const genAllowedTypes = pokemon.types.filter(type =>
      allowedTypes.some(allowedType => allowedType.url === type.type.url)
    );

    // Initialize sets for damage relations
    const doubleDamageFrom = new Set();
    const doubleDamageTo = new Set();
    const halfDamageFrom = new Set();
    const halfDamageTo = new Set();
    const noDamageFrom = new Set();
    const noDamageTo = new Set();

    // Fetch damage relations for each type the Pokémon has, only if it is a Generation 1 type
    await Promise.all(
      genAllowedTypes.map(async (type) => {
        const typeDetail = await fetch(type.type.url).then((res) => res.json());

        // Filter damage relations to exclude types with ID > 15
        typeDetail.damage_relations.double_damage_from.forEach((relation) => {
          const typeId = parseInt(relation.url.split("/").slice(-2, -1)[0], 10);
          if (typeId <= 15) {
            doubleDamageFrom.add(relation.name);
          }
        });

        typeDetail.damage_relations.double_damage_to.forEach((relation) => {
          const typeId = parseInt(relation.url.split("/").slice(-2, -1)[0], 10);
          if (typeId <= 15) {
            doubleDamageTo.add(relation.name);
          }
        });

        typeDetail.damage_relations.half_damage_from.forEach((relation) => {
          const typeId = parseInt(relation.url.split("/").slice(-2, -1)[0], 10);
          if (typeId <= 15) {
            halfDamageFrom.add(relation.name);
          }
        });

        typeDetail.damage_relations.half_damage_to.forEach((relation) => {
          const typeId = parseInt(relation.url.split("/").slice(-2, -1)[0], 10);
          if (typeId <= 15) {
            halfDamageTo.add(relation.name);
          }
        });

        typeDetail.damage_relations.no_damage_from.forEach((relation) => {
          const typeId = parseInt(relation.url.split("/").slice(-2, -1)[0], 10);
          if (typeId <= 15) {
            noDamageFrom.add(relation.name);
          }
        });

        typeDetail.damage_relations.no_damage_to.forEach((relation) => {
          const typeId = parseInt(relation.url.split("/").slice(-2, -1)[0], 10);
          if (typeId <= 15) {
            noDamageTo.add(relation.name);
          }
        });
      })
    );

    const growthRateData = await fetch(pokemonSpecies.growth_rate.url).then(res => res.json());
    const experienceToLevel100 = getExperienceForLevel100(growthRateData);

    displayPokemonDetails(pokemon, pokemonSpecies, experienceToLevel100, doubleDamageTo, doubleDamageFrom, halfDamageTo, halfDamageFrom, noDamageTo, noDamageFrom);
  } catch (error) {
    console.error("Error fetching Pokémon data:", error);
  }
}

function getExperienceForLevel100(growthRateData) {
  const level100Data = growthRateData.levels.find(level => level.level === 100);
  return level100Data ? level100Data.experience : "N/A";
}

function displayPokemonDetails(pokemon, pokemonSpecies, experienceToLevel100, doubleDamageTo, doubleDamageFrom, halfDamageTo, halfDamageFrom, noDamageTo, noDamageFrom) {
  document.getElementById("pokemon-id").textContent = `#${String(pokemon.id).padStart(3, '0')}`;
  document.getElementById("pokemon-name").textContent = capitalizeFirstLetter(pokemon.name);
  document.getElementById("pokemon-type").textContent = `Type: ${pokemon.types.map(t => t.type.name).join(", ")}`;
  document.getElementById("pokemon-abilities").textContent = `Abilities: ${pokemon.abilities.map(a => a.ability.name).join(", ")}`;
  document.getElementById("pokemon-height").textContent = `Height: ${pokemon.height / 10} m`;
  document.getElementById("pokemon-weight").textContent = `Weight: ${pokemon.weight / 10} kg`;
  document.getElementById("pokemon-image").src = `https://raw.githubusercontent.com/LuckPillow/PokedexChatbot/refs/heads/main/ASSETS/pokemon/${pokemon.id}.png`;

  // Display stats
  const stats = {
    hp: pokemon.stats[0].base_stat,
    attack: pokemon.stats[1].base_stat,
    defense: pokemon.stats[2].base_stat,
    spAttack: pokemon.stats[3].base_stat,
    spDefense: pokemon.stats[4].base_stat,
    speed: pokemon.stats[5].base_stat,
  };

  document.getElementById("stat-hp").textContent = stats.hp;
  document.getElementById("stat-attack").textContent = stats.attack;
  document.getElementById("stat-defense").textContent = stats.defense;
  document.getElementById("stat-sp-attack").textContent = stats.spAttack;
  document.getElementById("stat-sp-defense").textContent = stats.spDefense;
  document.getElementById("stat-speed").textContent = stats.speed;

  // Set progress bars
  document.getElementById("progress-hp").value = stats.hp;
  document.getElementById("progress-attack").value = stats.attack;
  document.getElementById("progress-defense").value = stats.defense;
  document.getElementById("progress-special-attack").value = stats.spAttack;
  document.getElementById("progress-special-defense").value = stats.spDefense;
  document.getElementById("progress-speed").value = stats.speed;

  // Set Pokedex entries
  document.getElementById("leafgreen-entry").textContent = `LeafGreen: ${getFlavorText(pokemonSpecies, "leafgreen")}`;
  document.getElementById("firered-entry").textContent = `FireRed: ${getFlavorText(pokemonSpecies, "firered")}`;

  // Display growth rate, experience to level 100, and capture rate
  document.getElementById("growth-rate").textContent = `${pokemonSpecies.growth_rate.name}`;
  document.getElementById("level100-experience").textContent = `${experienceToLevel100}`;
  document.getElementById("capture-rate").textContent = `${pokemonSpecies.capture_rate}`;

  // Set background color based on type
  setTypeBackgroundColor(pokemon);

  // Process and display damage relations
  displayDamageRelations(doubleDamageTo, doubleDamageFrom, halfDamageTo, halfDamageFrom, noDamageTo, noDamageFrom);
}

function getFlavorText(species, version) {
  const entry = species.flavor_text_entries.find(
    (text) => text.language.name === "en" && text.version.name === version
  );
  return entry ? entry.flavor_text.replace(/\f/g, " ") : "No description available.";
}

function displayDamageRelations(doubleDamageTo, doubleDamageFrom, halfDamageTo, halfDamageFrom, noDamageTo, noDamageFrom) {
  displayTypeIcons("double-damage-to", doubleDamageTo);
  displayTypeIcons("double-damage-from", doubleDamageFrom);
  displayTypeIcons("half-damage-to", halfDamageTo);
  displayTypeIcons("half-damage-from", halfDamageFrom);
  displayTypeIcons("no-damage-to", noDamageTo);
  displayTypeIcons("no-damage-from", noDamageFrom);
}

function displayTypeIcons(elementId, typesSet) {
  const container = document.getElementById(elementId);
  container.innerHTML = ""; // Clear previous content

  if (typesSet.size === 0) {
    container.textContent = "None";
    return;
  }

  typesSet.forEach(type => {
    const img = document.createElement("img");
    img.src = `https://raw.githubusercontent.com/LuckPillow/PokedexChatbot/refs/heads/main/ASSETS/types/${type}.png`; // Use the base URL for type images
    img.alt = type;
    img.classList.add("type-icon"); // Add a class for styling if needed
    container.appendChild(img);
  });
}



function setTypeBackgroundColor(pokemon) {
  const type = pokemon.types[0].type.name;
  const color = typeColors[type] || "#FFF";
  document.body.style.backgroundColor = color;
}

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const typeColors = {
  normal: "#A8A878",
  fire: "#F08030",
  water: "#6890F0",
  electric: "#F8D030",
  grass: "#78C850",
  ice: "#98D8D8",
  fighting: "#C03028",
  poison: "#A040A0",
  ground: "#E0C068",
  flying: "#A890F0",
  psychic: "#F85888",
  bug: "#A8B820",
  rock: "#B8A038",
  ghost: "#705898",
  dragon: "#7038F8",
  dark: "#705848",
  steel: "#B8B8D0",
  fairy: "#A8A878",
};

async function loadPokemonList() {
  const pokemonListContainer = document.getElementById("pokemon-list");
  pokemonListContainer.innerHTML = "";

  for (let i = 1; i <= 151; i++) {
    const pokemon = await fetch(`https://pokeapi.co/api/v2/pokemon/${i}`).then(res => res.json());
    const listItem = document.createElement("div");
    listItem.className = "pokemon-list-item";

    const img = document.createElement("img");
    img.src = `https://raw.githubusercontent.com/LuckPillow/PokedexChatbot/refs/heads/main/ASSETS/pokemonsprites2/${i}.png`;
    img.alt = pokemon.name;
    img.addEventListener("click", () => {
      window.location.href = `./detail?id=${i}`;
    });

    listItem.appendChild(img);
    pokemonListContainer.appendChild(listItem);
  }
}
