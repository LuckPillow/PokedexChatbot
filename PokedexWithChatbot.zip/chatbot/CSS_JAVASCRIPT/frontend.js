let token = sessionStorage.getItem('token') || '';
let username = sessionStorage.getItem('username') || '';

// Check if the user is already logged in
document.addEventListener('DOMContentLoaded', () => {
    if (token) {
        document.getElementById('auth').style.display = 'none';
        document.getElementById('pokemon').style.display = 'block';
        document.getElementById('addPokemonBox').style.display = 'block'; // Show addPokemonBox after login
        displayUsername(username);
        fetchPokemon();
    } else {
        document.getElementById('auth').style.display = 'block';
        document.getElementById('pokemon').style.display = 'none';
        document.getElementById('addPokemonBox').style.display = 'none'; // Hide addPokemonBox when not logged in
    }

    // Toggle between Login and Register forms
    document.getElementById('showLogin').addEventListener('click', showLoginForm);
    document.getElementById('showRegister').addEventListener('click', showRegisterForm);

    // Toggle visibility of Add Pokémon form
    document.getElementById('showAddPokemonForm').addEventListener('click', toggleAddPokemonForm);
});

// Toggle Login Form
function showLoginForm() {
    document.getElementById('loginFormContainer').style.display = 'block';
    document.getElementById('registerFormContainer').style.display = 'none';
}

// Toggle Register Form
function showRegisterForm() {
    document.getElementById('loginFormContainer').style.display = 'none';
    document.getElementById('registerFormContainer').style.display = 'block';
}

// Toggle Add Pokémon Form
function toggleAddPokemonForm() {
    const addPokemonFormContainer = document.getElementById('addPokemonFormContainer');
    addPokemonFormContainer.style.display = addPokemonFormContainer.style.display === 'none' || addPokemonFormContainer.style.display === '' ? 'block' : 'none';
}

// Register
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('regUsername').value;
    const password = document.getElementById('regPassword').value;

    const response = await fetch('http://localhost:3000/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });
    const result = await response.text();
    alert(result);
});

// Login
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    const response = await fetch('http://localhost:3000/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });
    const result = await response.json();
    if (result.token) {
        token = result.token;
        sessionStorage.setItem('token', token);
        sessionStorage.setItem('username', username);
        document.getElementById('auth').style.display = 'none';
        document.getElementById('pokemon').style.display = 'block';
        document.getElementById('addPokemonBox').style.display = 'block'; // Show addPokemonBox after successful login
        displayUsername(username);
        fetchPokemon();
    } else {
        alert('Login failed!');
    }
});

// Base URL for the custom Pokémon images on GitHub
const customImageBaseUrl = 'https://raw.githubusercontent.com/LuckPillow/PokedexChatbot/refs/heads/main/ASSETS/pokemon/';

async function fetchPokemon() {
    const token = sessionStorage.getItem('token');
    const response = await fetch('http://localhost:3000/pokemon', {
        headers: { 'Authorization': token }
    });
    const pokemonList = await response.json();
    const pokemonListElement = document.getElementById('pokemonList');
    pokemonListElement.innerHTML = '';

    // Fetch Pokémon data from PokéAPI by name
    for (const pokemon of pokemonList) {
        const listItem = document.createElement('li');
        const details = document.createElement('span');
        details.textContent = `${pokemon.name} (Type: ${pokemon.type}, Level: ${pokemon.level}) `;

        try {
            // Fetch data from PokéAPI to get the Pokémon's ID
            const pokeApiResponse = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemon.name.toLowerCase()}`);
            const pokeApiData = await pokeApiResponse.json();

            // Extract the Pokémon's ID from the PokéAPI data
            const pokemonId = pokeApiData.id;

            // Construct the image URL using the ID from the PokéAPI data
            const pokemonImage = document.createElement('img');
            pokemonImage.src = `${customImageBaseUrl}${pokemonId}.png`;
            pokemonImage.alt = `${pokemon.name} image`;
            pokemonImage.width = 50; // Adjust width as needed
            pokemonImage.height = 50; // Adjust height as needed

            listItem.appendChild(pokemonImage); // Append image to list item
        } catch (error) {
            console.error(`Error fetching data for ${pokemon.name}:`, error);
            details.textContent += " (Image unavailable)";
        }

        // Create delete button
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', () => deletePokemon(pokemon.id));

        listItem.appendChild(details);
        listItem.appendChild(deleteButton);
        pokemonListElement.appendChild(listItem);
    }
}

// Delete Pokémon function
async function deletePokemon(id) {
    const token = sessionStorage.getItem('token');
    await fetch(`http://localhost:3000/pokemon/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': token }
    });
    fetchPokemon(); // Refresh the list after deletion
}

// Add Pokémon
document.getElementById('addPokemonForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('pokemonName').value;
    const type = document.getElementById('pokemonType').value;
    const level = document.getElementById('pokemonLevel').value;

    await fetch('http://localhost:3000/pokemon', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token
        },
        body: JSON.stringify({ name, type, level })
    });
    fetchPokemon();
});

// Logout
document.getElementById('logout').addEventListener('click', () => {
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('username');
    document.getElementById('auth').style.display = 'block';
    document.getElementById('pokemon').style.display = 'none';
    document.getElementById('addPokemonBox').style.display = 'none'; // Hide addPokemonBox on logout
    document.getElementById('userDisplay').textContent = '';
});

// Display Username
function displayUsername(username) {
    const userDisplay = document.getElementById('userDisplay');
    userDisplay.style.display = 'block';
    userDisplay.textContent = `Logged in as: ${username}`;
}
