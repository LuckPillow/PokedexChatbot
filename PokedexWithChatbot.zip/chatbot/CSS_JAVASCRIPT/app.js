const express = require('express');
const mysql = require('mysql');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors'); // Import cors

const app = express();
app.use(express.json());

app.use(cors());

app.use(express.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'D@rkBunny9876',
    database: 'pokemon_app'
});

db.connect(err => {
    if (err) throw err;
    console.log('Connected to MySQL');
});

const jwtSecret = 'e543031b61a61f6ad94871add059ac569e2ad94e7cdbee9c1c8c8cd3c7ec4ac7d67ecbc88970a7bda93941bc48a5efd08aef92c528a1d6a0b0235bb15703f2ee';

app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const hash = bcrypt.hashSync(password, 8);

    db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, hash], (err) => {
        if (err) return res.status(500).send('User registration failed.');
        res.send('User registered successfully');
    });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;

    db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err || results.length === 0) return res.status(400).send('User not found.');

        const user = results[0];
        const isPasswordValid = bcrypt.compareSync(password, user.password);
        if (!isPasswordValid) return res.status(401).send('Invalid password.');

        const token = jwt.sign({ userId: user.id }, jwtSecret, { expiresIn: '1h' });
        res.json({ token });
    });
});

function authenticateToken(req, res, next) {
    const token = req.headers['authorization'];
    if (!token) return res.status(403).send('Token is required.');

    jwt.verify(token, jwtSecret, (err, user) => {
        if (err) return res.status(401).send('Invalid token.');
        req.user = user;
        next();
    });
}

app.post('/pokemon', authenticateToken, (req, res) => {
    const { name, type, level } = req.body;
    const userId = req.user.userId;

    db.query('INSERT INTO pokemon (user_id, name, type, level) VALUES (?, ?, ?, ?)', [userId, name, type, level], (err) => {
        if (err) return res.status(500).send('Failed to add Pokémon.');
        res.send('Pokémon added successfully.');
    });
});

app.put('/pokemon/:id', authenticateToken, (req, res) => {
    const { level } = req.body; 
    const userId = req.user.userId;
    const pokemonId = req.params.id;

    db.query(
        'UPDATE pokemon SET level = ? WHERE id = ? AND user_id = ?',
        [level, pokemonId, userId],
        (err) => {
            if (err) return res.status(500).send('Failed to update Pokémon level.');
            res.send('Pokémon level updated successfully.');
        }
    );
});


app.delete('/pokemon/:id', authenticateToken, (req, res) => {
    const userId = req.user.userId;
    const pokemonId = req.params.id;

    db.query('DELETE FROM pokemon WHERE id = ? AND user_id = ?', [pokemonId, userId], (err) => {
        if (err) return res.status(500).send('Failed to delete Pokémon.');
        res.send('Pokémon deleted successfully.');
    });
});

app.get('/pokemon', authenticateToken, (req, res) => {
    const userId = req.user.userId;

    db.query('SELECT * FROM pokemon WHERE user_id = ?', [userId], (err, results) => {
        if (err) return res.status(500).send('Failed to retrieve Pokémon.');
        res.json(results);
    });
});


app.put('/pokemon/:id', async (req, res) => {
    const pokemonId = req.params.id;
    const userId = req.user.id; 
    const { level } = req.body;

    try {
        const pokemon = await db('pokemon').where({ id: pokemonId, user_id: userId }).first();

        if (pokemon) {
            await db('pokemon')
                .where({ id: pokemonId })
                .update({ level });
            res.status(200).json({ message: 'Pokémon level updated successfully' });
        } else {
            res.status(403).json({ message: 'Unauthorized to update this Pokémon' });
        }
    } catch (error) {
        console.error('Error updating Pokémon level:', error);
        res.status(500).json({ message: 'Failed to update Pokémon level' });
    }
});




app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});