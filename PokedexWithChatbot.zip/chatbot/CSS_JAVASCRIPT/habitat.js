const habitatUrl = 'https://pokeapi.co/api/v2/pokemon-habitat/';
const maxPokemonId = 151;
const imageUrlTemplate = 'https://raw.githubusercontent.com/LuckPillow/PokedexChatbot/refs/heads/main/ASSETS/pokemon/${id}.png';
const habitatImageUrlTemplate = 'https://raw.githubusercontent.com/LuckPillow/PokedexChatbot/refs/heads/main/ASSETS/habitats/${habitatName}.png';

// Function to fetch and list Pokémon habitats
async function getPokemonHabitats() {
    try {
        const response = await fetch(habitatUrl);
        const data = await response.json();

        const habitatList = document.getElementById('habitat-list');
        habitatList.innerHTML = '';

        // Loop through habitats and fetch Pokémon data
        for (const habitat of data.results) {
            const habitatName = habitat.name;
            const habitatDiv = document.createElement('div');
            habitatDiv.classList.add('habitat');

            const habitatTitle = document.createElement('h2');
            habitatTitle.textContent = capitalizeFirstLetter(habitatName);
            habitatTitle.classList.add('dropdown-title');
            habitatDiv.appendChild(habitatTitle);

            // Create a container for the Pokémon list that will be collapsible
            const pokemonContainer = document.createElement('div');
            pokemonContainer.classList.add('pokemon-container', 'collapsed');

            const pokemonList = await fetchHabitatPokemon(habitat.url);
            const uniquePokemonList = filterUniquePokemon(pokemonList);
            const limitedPokemonList = uniquePokemonList.filter(pokemon => pokemon.id <= maxPokemonId);

            if (limitedPokemonList.length > 0) {
                const ul = document.createElement('ul');
                ul.classList.add('pokemon-list');
                limitedPokemonList.forEach(pokemon => {
                    const li = document.createElement('li');
                    li.classList.add('pokemon-item');

                    const img = document.createElement('img');
                    img.src = imageUrlTemplate.replace('${id}', pokemon.id); // Replace template with actual ID
                    img.alt = pokemon.name;

                    const pokemonName = document.createElement('span');
                    pokemonName.textContent = capitalizeFirstLetter(pokemon.name);

                    li.appendChild(img);
                    li.appendChild(pokemonName);
                    ul.appendChild(li);

                    // Click event to update the center display
                    li.addEventListener('click', () => {
                        displayHabitat(habitatName);
                    });
                });
                pokemonContainer.appendChild(ul);
            } else {
                const noPokemonMsg = document.createElement('p');
                noPokemonMsg.textContent = 'No Pokémon found in this habitat (within first 151).';
                pokemonContainer.appendChild(noPokemonMsg);
            }

            habitatDiv.appendChild(pokemonContainer);
            habitatList.appendChild(habitatDiv);

            // Add click event to toggle the Pokémon list
            habitatTitle.addEventListener('click', () => {
                pokemonContainer.classList.toggle('collapsed');
            });
        }
    } catch (error) {
        console.error('Error fetching habitats:', error);
    }
}

// Function to fetch Pokémon in a habitat
async function fetchHabitatPokemon(habitatUrl) {
    try {
        const response = await fetch(habitatUrl);
        const data = await response.json();

        const pokemonPromises = data.pokemon_species.map(async (species) => {
            const speciesUrl = species.url;
            const speciesResponse = await fetch(speciesUrl);
            const speciesData = await speciesResponse.json();
            return {
                name: speciesData.name,
                id: speciesData.id
            };
        });

        const pokemonList = await Promise.all(pokemonPromises);
        return pokemonList;
    } catch (error) {
        console.error('Error fetching Pokémon for habitat:', error);
        return [];
    }
}

// Function to filter unique Pokémon by name
function filterUniquePokemon(pokemonList) {
    const uniquePokemonMap = new Map();
    pokemonList.forEach(pokemon => {
        if (!uniquePokemonMap.has(pokemon.name)) {
            uniquePokemonMap.set(pokemon.name, pokemon);
        }
    });
    return Array.from(uniquePokemonMap.values());
}

// Function to display habitat image in the center
function displayHabitat(habitatName) {
    const centerDisplay = document.getElementById('center-display');
    centerDisplay.innerHTML = ''; // Clear any previous content

    const habitatImage = document.createElement('img');
    habitatImage.src = habitatImageUrlTemplate.replace('${habitatName}', habitatName.toLowerCase());
    habitatImage.alt = `${capitalizeFirstLetter(habitatName)} Habitat Image`;
    habitatImage.style.maxWidth = '100%';
    habitatImage.style.height = 'auto';

    // Append only the habitat image, no text
    centerDisplay.appendChild(habitatImage);
}

// Utility function to capitalize the first letter of a string
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

// Fetch and display habitats on page load
getPokemonHabitats();
